package com.mueblesstgo.ms_autorizacion_hhee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsAutorizacionHheeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAutorizacionHheeApplication.class, args);
	}

}
