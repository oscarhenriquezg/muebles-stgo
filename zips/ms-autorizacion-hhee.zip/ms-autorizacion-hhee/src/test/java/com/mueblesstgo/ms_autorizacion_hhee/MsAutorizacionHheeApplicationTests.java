package com.mueblesstgo.ms_autorizacion_hhee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAutorizacionHheeApplicationTests {

	@Test
	void contextLoads() {
	}

}
