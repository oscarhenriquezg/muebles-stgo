package com.mueblesstgo.ms_calculo_planilla_sueldos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCalculoPlanillaSueldosApplicationTests {

	@Test
	void contextLoads() {
	}

}
