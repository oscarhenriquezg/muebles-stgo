package com.mueblesstgo.ms_api_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
