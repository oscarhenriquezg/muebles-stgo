package com.mueblesstgo.ms_justificativos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsJustificativosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsJustificativosApplication.class, args);
	}

}
