package com.mueblesstgo.ms_justificativos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsJustificativosApplicationTests {

	@Test
	void contextLoads() {
	}

}
