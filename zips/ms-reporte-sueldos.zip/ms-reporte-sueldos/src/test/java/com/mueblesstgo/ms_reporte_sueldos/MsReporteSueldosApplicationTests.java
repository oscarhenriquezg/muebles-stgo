package com.mueblesstgo.ms_reporte_sueldos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsReporteSueldosApplicationTests {

	@Test
	void contextLoads() {
	}

}
