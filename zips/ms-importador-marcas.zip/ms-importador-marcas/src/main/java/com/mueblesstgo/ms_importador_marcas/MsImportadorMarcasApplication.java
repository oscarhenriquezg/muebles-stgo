package com.mueblesstgo.ms_importador_marcas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsImportadorMarcasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsImportadorMarcasApplication.class, args);
	}

}
