package com.mueblesstgo.ms_importador_marcas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsImportadorMarcasApplicationTests {

	@Test
	void contextLoads() {
	}

}
