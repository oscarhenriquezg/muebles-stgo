import { Armchair } from 'lucide-react'
import Link from "next/link"

export function TopBar() {
  return (
    <header className="bg-black fixed top-0 left-0 right-0 z-10 h-16 flex items-center justify-center">
      <Link href="/">
        <Armchair className="h-8 w-8 text-orange-500" />
      </Link>
    </header>
  )
}

