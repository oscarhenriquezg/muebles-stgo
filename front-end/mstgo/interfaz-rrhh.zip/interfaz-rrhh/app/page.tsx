import { Sidebar } from "@/components/sidebar"
import { TopBar } from "@/components/top-bar"

export default function Home() {
  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <TopBar />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-y-auto p-6">
          <h1 className="text-2xl font-semibold text-gray-800">Bienvenido al Sistema de RRHH</h1>
          <p className="mt-2 text-gray-600">Seleccione una opción del menú para comenzar.</p>
        </main>
      </div>
    </div>
  )
}

