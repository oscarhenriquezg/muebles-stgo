import { Button } from "@/components/ui/button"
import { Users } from 'lucide-react'
import Link from "next/link"

export function TopBar() {
  return (
    <header className="bg-white shadow-sm fixed top-0 left-0 right-0 z-10 h-16">
      <div className="py-4 px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-indigo-600" />
            <h1 className="ml-3 text-2xl font-bold leading-7 text-gray-900 sm:leading-9 sm:truncate">
              Sistema de RRHH
            </h1>
          </div>
          <div>
            <Button asChild variant="outline">
              <Link href="/">
                Volver al Menú Principal
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}

