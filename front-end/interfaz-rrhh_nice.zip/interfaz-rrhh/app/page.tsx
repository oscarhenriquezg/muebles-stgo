import { Sidebar } from "@/components/sidebar"
import { TopBar } from "@/components/top-bar"
import Image from 'next/image'

export default function Home() {
  return (
    <div className="flex flex-col h-screen">
      <TopBar />
      <div className="flex flex-1 pt-16">
        <Sidebar />
        <main className="flex-1 overflow-y-auto p-6 bg-gray-100">
          <h1 className="text-2xl font-semibold text-gray-800">Bienvenido al Sistema de RRHH</h1>
          <p className="mt-2 text-gray-600">Seleccione una opción del menú para comenzar.</p>
        </main>
      </div>
    </div>
  )
}

